/*    */ package it.sauronsoftware.jave;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputFormatException
/*    */   extends EncoderException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   InputFormatException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   InputFormatException(String message)
/*    */   {
/* 35 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jave-1.0.2.jar!\it\sauronsoftware\jave\InputFormatException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */