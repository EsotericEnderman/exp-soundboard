/*    */ package it.sauronsoftware.jave;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProcessKiller
/*    */   extends Thread
/*    */ {
/*    */   private Process process;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ProcessKiller(Process process)
/*    */   {
/* 41 */     this.process = process;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void run()
/*    */   {
/* 48 */     this.process.destroy();
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jave-1.0.2.jar!\it\sauronsoftware\jave\ProcessKiller.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */