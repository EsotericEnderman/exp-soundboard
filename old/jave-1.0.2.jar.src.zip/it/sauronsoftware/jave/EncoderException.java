/*    */ package it.sauronsoftware.jave;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EncoderException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   EncoderException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   EncoderException(String message)
/*    */   {
/* 35 */     super(message);
/*    */   }
/*    */   
/*    */   EncoderException(Throwable cause) {
/* 39 */     super(cause);
/*    */   }
/*    */   
/*    */   EncoderException(String message, Throwable cause) {
/* 43 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jave-1.0.2.jar!\it\sauronsoftware\jave\EncoderException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */