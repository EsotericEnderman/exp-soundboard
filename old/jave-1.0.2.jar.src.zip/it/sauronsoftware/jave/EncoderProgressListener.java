package it.sauronsoftware.jave;

public abstract interface EncoderProgressListener
{
  public abstract void sourceInfo(MultimediaInfo paramMultimediaInfo);
  
  public abstract void progress(int paramInt);
  
  public abstract void message(String paramString);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jave-1.0.2.jar!\it\sauronsoftware\jave\EncoderProgressListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */